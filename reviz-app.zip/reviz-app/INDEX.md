# 📁 Structure du projet Reviz

## 📂 Arborescence complète

```
reviz-app/
│
├── 📄 README.md                 ← Guide complet de déploiement
├── 📄 QUICKSTART.md             ← Démarrage rapide (5 minutes)
├── 📄 TODO.md                   ← Liste des tâches à faire
├── 📄 TROUBLESHOOTING.md        ← Résolution des problèmes
├── 📄 MARKETING.md              ← Guide marketing (0€ budget)
├── 📄 RENDER_ENV_VARS.md        ← Variables d'environnement Render
│
├── 🔧 Configuration
│   ├── .env                     ← Variables d'environnement (LOCAL)
│   ├── .env.example             ← Template des variables
│   ├── .gitignore               ← Fichiers à ignorer sur Git
│   ├── package.json             ← Dépendances backend
│   ├── render.yaml              ← Config automatique Render
│   ├── start.bat                ← Script de démarrage (Windows)
│   └── start.sh                 ← Script de démarrage (Mac/Linux)
│
├── 🖥️ Backend (Node.js + Express)
│   └── server.js                ← Serveur API principal
│
└── 📱 Frontend (React)
    └── client/
        ├── package.json         ← Dépendances frontend
        ├── .env                 ← Variables d'environnement frontend
        │
        ├── public/
        │   ├── index.html       ← Page HTML principale
        │   └── manifest.json    ← Config PWA
        │
        └── src/
            ├── index.js         ← Point d'entrée React
            ├── App.js           ← Composant principal
            │
            ├── styles/
            │   └── index.css    ← Styles globaux
            │
            ├── components/
            │   ├── Header.js    ← En-tête avec logo
            │   └── Sidebar.js   ← Liste des cours
            │
            └── pages/
                ├── HomePage.js       ← Page d'accueil (upload cours)
                ├── FlashcardsPage.js ← Affichage des fiches
                ├── QuizPage.js       ← QCM interactifs
                └── SuccessPage.js    ← Confirmation paiement
```

---

## 📄 Description détaillée des fichiers

### 🎯 Guides et Documentation

#### **README.md** ⭐ COMMENCE ICI
- Guide complet de A à Z
- Instructions de déploiement sur Render
- Configuration Stripe et OpenAI
- FAQ et résolution de problèmes

#### **QUICKSTART.md**
- Démarrage ultra-rapide (5 min)
- Pour tester en local
- Pour déployer rapidement

#### **TODO.md**
- Liste de toutes les tâches à faire
- Objectifs par semaine/mois
- Checklist complète

#### **TROUBLESHOOTING.md**
- 10 problèmes courants et leurs solutions
- Commandes de diagnostic
- Où trouver les logs

#### **MARKETING.md**
- Plan marketing complet (0€ de budget)
- Stratégie TikTok/Reels
- Idées de contenu
- Timeline réaliste 0 → 1000 users

#### **RENDER_ENV_VARS.md**
- Toutes les variables d'environnement
- Comment les configurer sur Render
- Explications détaillées

---

### ⚙️ Fichiers de Configuration

#### **.env**
Variables d'environnement pour le développement local :
- Clés Stripe (déjà configurées)
- Clé OpenAI (À COMPLÉTER)
- Configuration serveur

#### **.gitignore**
Liste des fichiers à ne pas envoyer sur GitHub :
- node_modules
- .env (sécurité)
- logs

#### **package.json** (root)
Dépendances du backend :
- Express (serveur web)
- Stripe (paiements)
- OpenAI (génération IA)
- CORS, etc.

#### **render.yaml**
Configuration automatique pour Render :
- Backend web service
- Frontend static site
- Variables d'environnement

#### **start.bat / start.sh**
Scripts pour lancer l'app d'un clic :
- Windows : Double-clic sur `start.bat`
- Mac/Linux : `./start.sh`

---

### 🖥️ Backend (API)

#### **server.js** (549 lignes)
Le cœur de l'application backend :

**Routes API** :
```javascript
GET  /api/health                      // Vérifier que l'API fonctionne
GET  /api/stripe/public-key           // Obtenir la clé publique Stripe
POST /api/stripe/create-checkout      // Créer session de paiement
POST /api/stripe/webhook              // Recevoir événements Stripe
POST /api/generate-flashcards         // Générer fiches avec IA
POST /api/generate-quiz               // Générer QCM avec IA
POST /api/save-progress               // Sauvegarder progression
GET  /api/progress/:userId/:courseId  // Récupérer progression
```

**Fonctionnalités** :
- ✅ Gestion des paiements Stripe
- ✅ Génération de fiches avec OpenAI GPT-4
- ✅ Génération de QCM personnalisés
- ✅ Limitation gratuit vs Premium
- ✅ Suivi de progression
- ✅ CORS configuré

---

### 📱 Frontend (React)

#### **client/src/App.js** (158 lignes)
Composant principal qui orchestre toute l'app :
- Gestion de l'état global
- Navigation entre pages
- Gestion des cours
- Interface avec le backend

#### **client/src/components/**

**Header.js**
- Logo Reviz
- Bouton menu (sidebar)
- Bouton "Passer à Premium"
- Badge Premium

**Sidebar.js**
- Liste des cours
- Progression de chaque cours
- Suppression de cours
- Appel à l'action Premium

#### **client/src/pages/**

**HomePage.js** (250 lignes)
Page d'accueil :
- Formulaire pour coller un cours
- Upload de fichier texte
- Validation (min 50 caractères)
- Appel API pour générer fiches
- Section features
- Infos version gratuite

**FlashcardsPage.js** (280 lignes)
Affichage des fiches :
- Navigation entre fiches (←→)
- Affichage du contenu (titre, mots-clés, résumé, points clés)
- Barre de progression globale
- Bouton "Lancer le quiz"
- Marquage fiches maîtrisées

**QuizPage.js** (320 lignes)
QCM interactifs :
- Génération des questions avec IA
- Affichage question + 4 options
- Feedback immédiat (correct/incorrect)
- Explication de la réponse
- Score final
- Possibilité de refaire

**SuccessPage.js** (120 lignes)
Confirmation paiement :
- Message de bienvenue Premium
- Liste des avantages débloqués
- Lien vers portail Stripe
- Redirection vers l'app

#### **client/src/styles/index.css** (400 lignes)
Tous les styles CSS :
- Animations (fadeIn, slideIn, pulse)
- Boutons (primary, secondary)
- Cards
- Inputs / Textareas
- Progress bars
- Badges
- Spinner de chargement
- Responsive mobile

---

## 🔑 Fichiers critiques à configurer

### Avant de déployer, configure :

1. **/.env**
   ```
   OPENAI_API_KEY=sk-ta_cle_ici
   ```

2. **/client/.env**
   ```
   REACT_APP_API_URL=http://localhost:3001
   ```

3. Sur Render (Backend) :
   ```
   OPENAI_API_KEY=sk-ta_cle_ici
   FRONTEND_URL=https://ton-frontend.onrender.com
   ALLOWED_ORIGINS=https://ton-frontend.onrender.com
   ```

4. Sur Render (Frontend) :
   ```
   REACT_APP_API_URL=https://ton-backend.onrender.com
   ```

---

## 🚀 Ordre de lecture recommandé

**Pour démarrer rapidement** :
1. 📖 Lis **QUICKSTART.md**
2. ⚙️ Configure **.env** (ajoute ta clé OpenAI)
3. ▶️ Lance **start.bat** ou **start.sh**
4. 🧪 Teste sur http://localhost:3000

**Pour déployer** :
1. 📖 Lis **README.md** (section déploiement)
2. 🔐 Consulte **RENDER_ENV_VARS.md**
3. ✅ Suis les étapes du **TODO.md**

**Pour promouvoir** :
1. 📣 Lis **MARKETING.md**
2. 🎥 Crée tes premières vidéos TikTok
3. 📊 Suis les objectifs du **TODO.md**

**En cas de problème** :
1. 🔧 Consulte **TROUBLESHOOTING.md**
2. 📝 Vérifie les logs Render
3. 🔍 Google l'erreur exacte

---

## 📊 Statistiques du projet

```
Backend        : 549 lignes
Frontend       : ~1500 lignes
Guides         : ~3000 lignes
Total code     : ~2000 lignes
Total projet   : ~5000 lignes

Fichiers       : 25 fichiers
Dossiers       : 8 dossiers
Documentation  : 6 guides complets
```

---

## 🎯 Prochaines étapes

Tu as TOUT ce qu'il faut pour :
1. ✅ Tester l'app en local
2. ✅ La déployer gratuitement sur Render
3. ✅ Commencer à avoir des utilisateurs
4. ✅ Gagner tes premiers 9€/mois 💰

**Commence par le QUICKSTART.md et lance-toi ! 🚀**

---

## 🆘 Besoin d'aide ?

Tous les guides sont là pour toi :
- **QUICKSTART.md** → Démarrage rapide
- **README.md** → Guide complet
- **TROUBLESHOOTING.md** → Résolution de problèmes
- **TODO.md** → Plan d'action
- **MARKETING.md** → Promouvoir l'app

**Tu peux le faire ! Bon courage ! 💪**

---

*Dernière mise à jour : 4 février 2026*
*Version : 1.0.0*
*Créé avec ❤️ pour Alexandre Roudaut*
