# 📣 Guide Marketing - Reviz (Budget ZÉRO)

## 🎯 Objectif : Passer de 0 à 1000 utilisateurs en 3 mois

---

## 🚀 Phase 1 : Les 10 premiers utilisateurs (Semaine 1)

### Ton entourage immédiat

**✅ Actions à faire MAINTENANT** :

1. **Ton groupe WhatsApp/Snapchat de classe**
   ```
   Message à envoyer :
   "Salut les gars ! J'ai créé une app pour réviser plus vite. 
   Elle transforme vos cours en fiches + QCM automatiquement avec l'IA. 
   C'est gratuit et ça prend 2 min à tester : [TON_LIEN]
   
   Dites-moi ce que vous en pensez ! 🎓"
   ```

2. **Story Instagram/Snapchat**
   - Screenshot de l'app avec des fiches générées
   - Texte : "J'ai créé ça pour réviser, testez et dites-moi ! 🧠"
   - Lien en bio ou swipe up

3. **Demande à 3 amis de tester MAINTENANT**
   - Regarde-les utiliser l'app
   - Note TOUS leurs retours
   - Améliore ce qui bloque

**📊 Objectif Semaine 1** : 10 utilisateurs actifs

---

## 🎥 Phase 2 : TikTok/Reels (Semaine 2-4)

### Pourquoi TikTok ?
- ✅ Gratuit
- ✅ Potentiel viral énorme
- ✅ Ta cible (étudiants) y est massivement
- ✅ 1 vidéo = potentiellement 100k vues

### 📱 Idées de vidéos (30-60 secondes)

**Vidéo 1 : "POV : T'en as marre de réviser"**
```
[Tu filmes ton bureau rempli de cours]
Voix off : "J'en avais marre de passer des heures à faire des fiches..."
[Montre l'app]
"...alors j'ai créé une app qui le fait automatiquement avec l'IA"
[Montre le résultat : fiches + QCM]
"Lien en bio, c'est gratuit"

#etudiant #bac #brevet #revisions #ia #education
```

**Vidéo 2 : "Avant/Après Reviz"**
```
AVANT : [Toi stressé avec 50 pages de cours]
APRÈS : [Toi cool avec 3 fiches sur Reviz]
"Game changer pour le bac"

#bac2025 #revisions #astuces #etudiant
```

**Vidéo 3 : Tutoriel rapide**
```
[Screen recording de l'app]
"Comment j'ai transformé 5 pages de cours en fiches en 30 secondes"
[Montre le processus complet]
"Lien en bio"

#tuto #revisions #ia #productivite
```

**Vidéo 4 : Témoignage utilisateur**
```
[Demande à un ami de témoigner]
"Depuis que j'utilise Reviz, je gagne 2h par matière"
"J'ai eu 16 à mon DS d'histoire grâce aux QCM"

#bac #resultats #revisions
```

### 🎬 Conseils vidéo

- ✅ Format vertical (9:16)
- ✅ Hook dans les 3 premières secondes
- ✅ Sous-titres (beaucoup regardent sans son)
- ✅ Musique tendance du moment
- ✅ Hashtags pertinents (#bac2025 #revisions)
- ✅ Poste aux heures de pointe (12h-14h, 18h-20h)

**📊 Objectif** : 1 vidéo par jour pendant 2 semaines = 100-500 nouveaux utilisateurs

---

## 💬 Phase 3 : Reddit & Forums (Semaine 3-5)

### Où poster ?

**Reddit France** :
- r/France
- r/etudiant
- r/French (pour les étrangers apprenant le français)
- r/Bac
- r/SideProject (montre ton projet)
- r/startups

**Forums** :
- Studyrama
- Digischool
- Forums de lycées/facs
- Discord d'écoles

### 📝 Message type (adapte selon le contexte)

```
Titre : [J'ai créé une app gratuite pour réviser plus vite]

Salut !

Je suis lycéen/étudiant et je détestais passer des heures à faire des fiches 
de révision. Du coup, j'ai créé Reviz : une app qui transforme tes cours en 
fiches + QCM automatiquement avec l'IA.

✨ Fonctionnalités :
- Colle ton cours → L'IA génère 3 fiches résumées
- QCM automatiques pour s'auto-tester
- Suivi de progression
- 100% gratuit pour commencer

[TON_LIEN]

J'aimerais avoir vos retours pour l'améliorer ! Qu'en pensez-vous ?

PS : Je suis ouvert aux suggestions, c'est mon premier projet donc soyez 
indulgents 😅
```

**💡 Astuce** : Sois humble, demande des retours, ne fais pas trop de pub agressive

**📊 Objectif** : 1 post par semaine = 50-200 nouveaux utilisateurs

---

## 👥 Phase 4 : Groupes Facebook (Semaine 4-8)

### Groupes à cibler

Recherche sur Facebook :
- "Bac 2025 [ta ville]"
- "Étudiants [ta fac]"
- "Lycée [ton lycée]"
- "Révisions Bac"
- "Étudiants en [ta matière]"

### 📱 Post type

```
[Screenshot de ton app]

🎓 App gratuite pour réviser plus vite !

Salut la commu ! Je partage une app que j'ai créée pour m'aider à réviser. 
Elle transforme tes cours en fiches + quiz automatiquement.

Ça m'a fait gagner un temps fou, peut-être que ça vous aidera aussi !

Lien : [TON_LIEN]

C'est gratuit et ça prend 2 min à tester 😊

#bac #revisions #etudiant
```

**⚠️ Attention** : Lis les règles du groupe avant de poster !

**📊 Objectif** : 2-3 groupes par semaine = 100-300 utilisateurs

---

## 🎓 Phase 5 : Partenariats locaux (Semaine 6-12)

### Délégués de classe

**Message à envoyer** :
```
Salut [prénom] !

Je sais que tu es délégué et j'ai créé une app gratuite qui pourrait 
aider toute la classe à réviser. Elle transforme les cours en fiches + QCM 
automatiquement.

Est-ce que tu pourrais la partager au groupe de la classe ? Ou même en 
parler au prof principal ?

Lien : [TON_LIEN]

Merci d'avance ! 😊
```

### Associations étudiantes

Contacte :
- BDE (Bureau Des Étudiants)
- Associations de ta fac
- Clubs de ton lycée

**Proposition** :
```
Salut !

Je suis [ton nom], élève en [ta classe/fac]. J'ai créé une app gratuite 
pour réviser (Reviz) et je cherche des partenaires pour la faire connaître.

Est-ce que vous seriez intéressés pour :
- Un post sur votre page Instagram ?
- Un mail à vos membres ?
- Un stand lors d'un événement ?

Je peux vous offrir un code promo Premium pour vos membres en échange !

[TON_LIEN]

Disponible pour en discuter 😊
```

**📊 Objectif** : 2-3 partenariats = 200-500 utilisateurs

---

## 🔥 Phase 6 : Bouche-à-oreille (Permanent)

### Programme de parrainage

**À intégrer dans l'app (v2)** :
```
"Invite 3 amis et gagne 1 mois de Premium gratuit"
```

### Incentive pour partager

**Après une bonne note :**
```
[Popup dans l'app]
"Bravo pour ton 18/20 ! 🎉
Aide tes amis à réussir aussi en partageant Reviz !"

[Bouton Partager]
```

---

## 📊 Métriques à suivre

### Semaine 1-4
- ✅ 10 → 50 → 200 utilisateurs
- ✅ 5-10 utilisateurs actifs quotidiens
- ✅ 2-3 fiches générées par utilisateur

### Semaine 5-8
- ✅ 200 → 500 utilisateurs
- ✅ 20-50 utilisateurs actifs quotidiens
- ✅ Premiers retours positifs

### Semaine 9-12
- ✅ 500 → 1000 utilisateurs
- ✅ 50-100 utilisateurs actifs quotidiens
- ✅ Premiers abonnements Premium 💰

---

## 💎 Phase 7 : Conversion vers Premium

### Quand pousser Premium ?

**Bon timing** :
- ✅ Après 3 cours créés (l'utilisateur voit la valeur)
- ✅ Quand il atteint la limite des 3 fiches
- ✅ Après un bon score au quiz (80%+)

**Mauvais timing** :
- ❌ Dès la première visite
- ❌ Popup agressive
- ❌ Avant qu'il ait testé les fonctionnalités

### Messages de conversion

**Message 1 - Subtil** :
```
"🎉 Bravo ! Vous maîtrisez ce cours.
💎 Avec Premium, débloquez 10 fiches supplémentaires pour approfondir."
```

**Message 2 - Comparaison** :
```
Gratuit : 3 fiches, 5 QCM
Premium : Fiches illimitées, 20 QCM, statistiques avancées

Seulement 9€/mois → Moins qu'un Starbucks !
```

**Message 3 - Urgence (pour le bac)** :
```
"Le bac, c'est dans 2 mois ! ⏰
Passez en Premium et maximisez vos révisions."
```

---

## 🎯 Timeline réaliste

```
Mois 1 : 0 → 200 utilisateurs
Mois 2 : 200 → 600 utilisateurs
Mois 3 : 600 → 1500 utilisateurs

Conversion Premium (2%) : 30 utilisateurs payants
Revenus : 30 × 9€ = 270€/mois 💰
```

---

## 💡 Astuces supplémentaires

### 1. Profite des périodes clés

- **Septembre** : Rentrée (pic d'inscriptions)
- **Novembre-Décembre** : Premiers DS/Partiels
- **Mars-Avril** : Bac blanc
- **Mai-Juin** : BAC (ÉNORME pic)

Pousse tes contenus TikTok/Reels à ces moments !

### 2. Témoignages > Pub

Demande à tes utilisateurs satisfaits :
- Screenshot de leur progression
- Témoignage écrit
- Vidéo de 15 secondes

Partage-les sur tes réseaux !

### 3. Sois réactif

- Réponds aux DM Instagram en < 1h
- Corrige les bugs signalés rapidement
- Écoute TOUS les retours

**Un utilisateur satisfait = 5 nouveaux utilisateurs via bouche-à-oreille**

---

## 🚫 Erreurs à ÉVITER

❌ Spam dans les commentaires
❌ Acheter des followers
❌ Fausses promesses ("Aie 20/20 garanti")
❌ Design moche (soigne l'app !)
❌ Bugs non corrigés
❌ Ignorer les retours utilisateurs

---

## ✅ Checklist Marketing Hebdomadaire

**Lundi** :
- [ ] 1 vidéo TikTok/Reels
- [ ] 1 post Reddit/Forum

**Mercredi** :
- [ ] 1 vidéo TikTok/Reels
- [ ] Répondre aux DM/commentaires

**Vendredi** :
- [ ] 1 vidéo TikTok/Reels
- [ ] 1 post groupe Facebook

**Dimanche** :
- [ ] Analyser les métriques
- [ ] Planifier la semaine suivante

---

## 🎯 Ton objectif immédiat

**Cette semaine** :
1. ✅ Fais tester à 5 amis
2. ✅ Fais 1 vidéo TikTok
3. ✅ Poste sur 1 groupe Facebook
4. ✅ Partage sur ton Instagram

**Si tu fais ça**, tu auras 20-30 utilisateurs d'ici vendredi ! 🚀

---

**Le marketing gratuit, c'est 80% de constance, 20% de créativité. GO GO GO ! 💪**
