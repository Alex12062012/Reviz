# ⚡ QUICKSTART - Démarrage Rapide

## 🎯 Pour tester en local (sur ton PC)

### 1. Installer Node.js
Télécharge et installe Node.js : [nodejs.org](https://nodejs.org) (version LTS)

### 2. Installer les dépendances

```bash
# Backend
cd reviz-app
npm install

# Frontend
cd client
npm install
cd ..
```

### 3. Configurer les variables d'environnement

Crée un fichier `.env` à la racine du projet :

```bash
cp .env.example .env
```

Édite le fichier `.env` et ajoute ta clé OpenAI :
```
OPENAI_API_KEY=sk-ta_cle_ici
```

### 4. Lancer l'application

**Terminal 1 - Backend :**
```bash
npm start
```

**Terminal 2 - Frontend :**
```bash
cd client
npm start
```

L'app s'ouvre automatiquement sur `http://localhost:3000` ! 🎉

---

## 🚀 Pour déployer sur Render (gratuit)

### Méthode ultra-rapide (5 minutes)

1. **GitHub** : Crée un repo et push ton code
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git remote add origin https://github.com/TON_USERNAME/reviz-app.git
   git push -u origin main
   ```

2. **Render Backend** :
   - Va sur [render.com](https://render.com)
   - New → Web Service
   - Connecte ton repo
   - Build: `npm install`
   - Start: `node server.js`
   - Ajoute les variables d'environnement (voir README)

3. **Render Frontend** :
   - New → Static Site
   - Root: `client`
   - Build: `npm install && npm run build`
   - Publish: `client/build`

4. **Connecter les deux** :
   - Backend : ajoute `FRONTEND_URL=https://ton-frontend.onrender.com`
   - Frontend : ajoute `REACT_APP_API_URL=https://ton-backend.onrender.com`

✅ **C'est en ligne !**

---

## 🔑 Obtenir une clé OpenAI

1. [platform.openai.com](https://platform.openai.com)
2. Créer un compte
3. API Keys → Create new secret key
4. Copier la clé (commence par `sk-`)
5. Ajouter dans `.env` (local) ou Render (production)

**💰 Coût** : 5$ gratuits à l'inscription = ~2500 fiches générées

---

## ✅ Vérifier que ça marche

### En local :
1. Va sur `http://localhost:3000`
2. Entre un cours de test (minimum 50 caractères)
3. Clique "Générer mes fiches"
4. Si ça marche → ✅

### En production :
1. Va sur ton URL Render
2. Même test
3. Si ça marche → 🎉

---

## 🐛 Problèmes courants

**"Cannot connect to backend"**
→ Vérifie que les URLs dans les variables d'environnement sont correctes

**"OpenAI API error"**
→ Vérifie que tu as du crédit sur ton compte OpenAI

**"Module not found"**
→ Lance `npm install` dans le dossier concerné

---

## 📱 Prochaines étapes

1. ✅ Teste l'app avec de vrais cours
2. ✅ Partage avec 5 amis
3. ✅ Améliore selon leurs retours
4. ✅ Fais un TikTok pour promouvoir
5. ✅ Gagne tes premiers 9€/mois 💰

---

**Besoin d'aide ? Regarde le README complet ou contacte-moi !**
