# 🎓 Reviz - Application SAAS Éducative

Transformez vos cours en fiches de révision et QCM automatiquement avec l'IA.

---

## 🚀 Déploiement sur Render (GRATUIT)

### Prérequis

1. **Compte GitHub** : Créer un compte sur [github.com](https://github.com)
2. **Compte Render** : Créer un compte sur [render.com](https://render.com)
3. **Compte OpenAI** : Créer un compte sur [openai.com](https://openai.com) et obtenir une clé API

---

## 📦 Étape 1 : Mettre le code sur GitHub

### Option A : Via GitHub Desktop (le plus simple)

1. Télécharge et installe **GitHub Desktop** : [desktop.github.com](https://desktop.github.com)
2. Connecte-toi avec ton compte GitHub
3. Clique sur **File → Add Local Repository**
4. Sélectionne le dossier `reviz-app`
5. Clique sur **Publish repository**
6. Nom : `reviz-app` (garde-le public pour Render gratuit)
7. Clique sur **Publish**

### Option B : Via ligne de commande (si tu es à l'aise)

```bash
cd reviz-app
git init
git add .
git commit -m "Initial commit - Reviz app"
git branch -M main
git remote add origin https://github.com/TON_USERNAME/reviz-app.git
git push -u origin main
```

---

## 🌐 Étape 2 : Déployer le Backend sur Render

### 2.1 Créer le service Backend

1. Va sur [render.com](https://render.com) et connecte-toi
2. Clique sur **New +** → **Web Service**
3. Connecte ton repository GitHub `reviz-app`
4. Configure comme suit :

```
Name: reviz-backend
Region: Frankfurt (Europe)
Branch: main
Root Directory: (laisse vide)
Runtime: Node
Build Command: npm install
Start Command: node server.js
Instance Type: Free
```

### 2.2 Variables d'environnement (IMPORTANT !)

Dans la section **Environment**, ajoute ces variables :

```
STRIPE_SECRET_KEY = sk_test_51Sx95w0bWDBDwCtUTY8JSBV9LKobbOY5CfRFNgAcSdVyrTpqsKWchCCZyy1iCkIy3Vd5jtX8QTBTwkUYBU8B1iZ0008SMZ6DZF
STRIPE_PUBLIC_KEY = pk_test_51Sx95w0bWDBDwCtUOIOx6hpcymOpySJjCckrzrTNA9INNznp4iJJhj0HvSvQHVVCFzzr7aJ213Bgj6MYfSP1sKxv00as5prznB
STRIPE_PRICE_ID = price_1Sx9CI0bWDBDwCtUnI2mkRd3
OPENAI_API_KEY = sk-... (ta clé OpenAI)
PORT = 3001
NODE_ENV = production
FRONTEND_URL = https://reviz-frontend.onrender.com
ALLOWED_ORIGINS = https://reviz-frontend.onrender.com,http://localhost:3000
```

⚠️ **IMPORTANT** : Remplace `https://reviz-frontend.onrender.com` par l'URL que Render te donnera pour le frontend (étape 3)

5. Clique sur **Create Web Service**
6. Attends 3-5 minutes que le déploiement se termine
7. **Note l'URL du backend** (ex: `https://reviz-backend.onrender.com`)

---

## 🎨 Étape 3 : Déployer le Frontend sur Render

### 3.1 Créer le service Frontend

1. Sur Render, clique sur **New +** → **Static Site**
2. Sélectionne ton repository `reviz-app`
3. Configure comme suit :

```
Name: reviz-frontend
Region: Frankfurt
Branch: main
Root Directory: client
Build Command: npm install && npm run build
Publish Directory: client/build
```

### 3.2 Variables d'environnement Frontend

```
REACT_APP_API_URL = https://reviz-backend.onrender.com
```

⚠️ Remplace par l'URL de ton backend (étape 2)

4. Clique sur **Create Static Site**
5. Attends 5-7 minutes
6. **Ton app est en ligne !** 🎉

---

## 🔑 Étape 4 : Obtenir une clé OpenAI

1. Va sur [platform.openai.com](https://platform.openai.com)
2. Crée un compte (carte bancaire requise mais **5$ de crédit gratuit**)
3. Va dans **API Keys** → **Create new secret key**
4. Copie la clé (commence par `sk-`)
5. Retourne sur Render → Backend → Environment
6. Ajoute la variable `OPENAI_API_KEY` avec ta clé

---

## ✅ Étape 5 : Vérifier que tout fonctionne

1. Va sur ton URL frontend : `https://reviz-frontend.onrender.com`
2. Entre un cours de test
3. Clique sur "Générer mes fiches"
4. Si ça marche → **BRAVO ! 🎉**

---

## 🐛 Résolution des problèmes

### Problème : "Cannot connect to backend"

**Solution** :
1. Vérifie que `REACT_APP_API_URL` dans le frontend pointe vers l'URL du backend
2. Vérifie que `FRONTEND_URL` dans le backend pointe vers l'URL du frontend
3. Re-déploie les deux services

### Problème : "OpenAI API error"

**Solution** :
1. Vérifie que ta clé OpenAI est correcte
2. Vérifie que tu as du crédit sur ton compte OpenAI
3. Va sur [platform.openai.com/usage](https://platform.openai.com/usage) pour voir ton utilisation

### Problème : Le site est lent au premier chargement

**Solution** : C'est normal ! Render gratuit met les services en veille après 15 min d'inactivité. Le premier chargement peut prendre 30-60 secondes.

---

## 💰 Coûts estimés

- **Render** : 0€ (plan gratuit)
- **OpenAI** : ~0.002$ par fiche générée
  - 1000 fiches ≈ 2$
  - 5$ gratuits à l'inscription = **2500 fiches gratuites**
- **Stripe** : 0€ (ils prennent juste 1.5% sur les paiements)

**Total : 0€ pour démarrer ! 🎉**

---

## 📱 Partager ton app

Une fois déployée, partage l'URL avec tes amis :
```
https://reviz-frontend.onrender.com
```

Tu peux aussi acheter un nom de domaine personnalisé (ex: `reviz.fr`) pour 10-15€/an et le connecter à Render.

---

## 🔒 Sécurité

⚠️ **IMPORTANT** : Les clés dans ce README sont en mode **TEST**. Quand tu voudras passer en mode LIVE :

1. Va sur Stripe Dashboard
2. Active le mode LIVE (bouton en haut à droite)
3. Crée de nouvelles clés API LIVE
4. Remplace les clés dans les variables d'environnement Render
5. Re-déploie

---

## 🆘 Besoin d'aide ?

Si tu as des problèmes :
1. Vérifie les logs sur Render (onglet "Logs")
2. Vérifie la console du navigateur (F12)
3. Contacte-moi avec une capture d'écran de l'erreur

---

## 🚀 Prochaines étapes

Une fois que l'app fonctionne :

1. ✅ Teste avec de vrais cours
2. ✅ Partage avec 5-10 amis pour avoir des retours
3. ✅ Améliore selon leurs suggestions
4. ✅ Fais un TikTok/Reel pour le promouvoir
5. ✅ Achète un domaine personnalisé (optionnel)

---

## 📊 Stack technique

- **Frontend** : React 18 + CSS custom
- **Backend** : Node.js + Express
- **IA** : OpenAI GPT-4
- **Paiements** : Stripe
- **Hébergement** : Render (gratuit)

---

**Créé avec ❤️ par Alexandre Roudaut**

*Bonne chance avec Reviz ! 🎓*
