# 🔐 Configuration des Variables d'Environnement sur Render

## 📋 Variables pour le BACKEND (Web Service)

Quand tu crées ton service backend sur Render, ajoute ces variables dans la section **Environment** :

```
STRIPE_SECRET_KEY
sk_test_51Sx95w0bWDBDwCtUTY8JSBV9LKobbOY5CfRFNgAcSdVyrTpqsKWchCCZyy1iCkIy3Vd5jtX8QTBTwkUYBU8B1iZ0008SMZ6DZF

STRIPE_PUBLIC_KEY
pk_test_51Sx95w0bWDBDwCtUOIOx6hpcymOpySJjCckrzrTNA9INNznp4iJJhj0HvSvQHVVCFzzr7aJ213Bgj6MYfSP1sKxv00as5prznB

STRIPE_PRICE_ID
price_1Sx9CI0bWDBDwCtUnI2mkRd3

OPENAI_API_KEY
sk-METS_TA_CLE_ICI

PORT
3001

NODE_ENV
production

FRONTEND_URL
https://reviz-frontend.onrender.com

ALLOWED_ORIGINS
https://reviz-frontend.onrender.com,http://localhost:3000
```

⚠️ **IMPORTANT** : Remplace `https://reviz-frontend.onrender.com` par l'URL réelle que Render te donnera pour ton frontend !

---

## 🎨 Variables pour le FRONTEND (Static Site)

Quand tu crées ton static site frontend sur Render, ajoute cette variable :

```
REACT_APP_API_URL
https://reviz-backend.onrender.com
```

⚠️ **IMPORTANT** : Remplace `https://reviz-backend.onrender.com` par l'URL réelle de ton backend !

---

## 📝 Comment ajouter ces variables sur Render

### Pendant la création du service :

1. Scroll jusqu'à la section **Environment**
2. Clique sur **Add Environment Variable**
3. Pour chaque variable :
   - **Key** : le nom (ex: `OPENAI_API_KEY`)
   - **Value** : la valeur (ex: `sk-...`)
4. Répète pour toutes les variables

### Après la création du service :

1. Va dans ton service sur Render
2. Clique sur **Environment** dans le menu de gauche
3. Clique sur **Add Environment Variable**
4. Ajoute ou modifie les variables
5. Clique sur **Save Changes**
6. Le service va redémarrer automatiquement

---

## 🔑 Obtenir ta clé OpenAI

1. Va sur [platform.openai.com](https://platform.openai.com)
2. Créer un compte (carte bancaire requise)
3. Tu recevras **5$ de crédit gratuit**
4. Va dans **API Keys** → **Create new secret key**
5. Copie la clé (commence par `sk-proj-` ou `sk-`)
6. Colle-la dans la variable `OPENAI_API_KEY`

**💰 Coût estimé** :
- 1 fiche générée ≈ 0.002$
- 5$ gratuits = environ 2500 fiches
- Largement suffisant pour tester et avoir tes premiers users !

---

## ✅ Vérification

Une fois toutes les variables configurées :

1. **Backend** : Va sur `https://ton-backend.onrender.com/api/health`
   - Tu devrais voir : `{"status": "OK", "message": "Reviz API is running!"}`

2. **Frontend** : Va sur `https://ton-frontend.onrender.com`
   - L'interface Reviz devrait s'afficher

3. **Test complet** :
   - Entre un cours de test
   - Clique sur "Générer mes fiches"
   - Si les fiches apparaissent → ✅ Tout fonctionne !

---

## 🐛 Dépannage

### Erreur "Cannot connect to backend"

**Cause** : Le frontend ne trouve pas le backend

**Solution** :
1. Vérifie que `REACT_APP_API_URL` dans le frontend = URL exacte du backend
2. Vérifie qu'il n'y a pas de `/` à la fin de l'URL
3. Redéploie le frontend

### Erreur "OpenAI API error"

**Cause** : Problème avec la clé OpenAI

**Solution** :
1. Vérifie que la clé commence bien par `sk-`
2. Va sur [platform.openai.com/usage](https://platform.openai.com/usage) pour voir ton crédit restant
3. Vérifie que tu as ajouté une carte bancaire (obligatoire même avec crédit gratuit)

### Erreur "CORS error"

**Cause** : Le backend n'autorise pas les requêtes du frontend

**Solution** :
1. Vérifie que `FRONTEND_URL` dans le backend = URL exacte du frontend
2. Vérifie que `ALLOWED_ORIGINS` contient l'URL du frontend
3. Redéploie le backend

---

## 🔄 Mettre à jour les variables

Si tu dois changer une variable après déploiement :

1. Va dans ton service Render
2. **Environment** → Trouve la variable
3. Clique sur **Edit** (icône crayon)
4. Change la valeur
5. **Save Changes**
6. Le service redémarre automatiquement (30-60 secondes)

---

## 🚀 Passage en mode LIVE (Stripe)

Quand tu es prêt à accepter de vrais paiements :

1. Va sur [dashboard.stripe.com](https://dashboard.stripe.com)
2. Active le mode **LIVE** (toggle en haut à droite)
3. Va dans **Developers** → **API Keys**
4. Copie les nouvelles clés (elles commencent par `sk_live_` et `pk_live_`)
5. Mets à jour ces variables sur Render :
   - `STRIPE_SECRET_KEY` → ta clé `sk_live_...`
   - `STRIPE_PUBLIC_KEY` → ta clé `pk_live_...`
6. Crée un nouveau produit Premium en mode LIVE
7. Mets à jour `STRIPE_PRICE_ID` avec le nouveau `price_...`
8. Redéploie

⚠️ **N'oublie pas** : En mode LIVE, les vrais paiements seront prélevés !

---

**Besoin d'aide ? Vérifie les logs sur Render ou contacte-moi !**
