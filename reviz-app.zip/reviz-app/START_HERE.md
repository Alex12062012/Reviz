# 🚀 COMMENCE ICI - 2 MINUTES

## 📍 Tu es ici : `/reviz-app/`

---

## ⚡ Option 1 : Tester EN LOCAL (sur ton PC)

### 1. Installe Node.js
👉 [nodejs.org](https://nodejs.org) (version LTS)

### 2. Configure ta clé OpenAI

Édite le fichier `.env` (à la racine) et ajoute ta clé :
```
OPENAI_API_KEY=sk-ta_cle_ici
```

> 🔑 Pas encore de clé ? → [platform.openai.com/api-keys](https://platform.openai.com/api-keys)

### 3. Lance l'app

**Windows** : Double-clique sur `start.bat`

**Mac/Linux** :
```bash
chmod +x start.sh
./start.sh
```

### 4. Ouvre ton navigateur

👉 [http://localhost:3000](http://localhost:3000)

✅ **C'est tout ! L'app fonctionne !**

---

## 🌐 Option 2 : DÉPLOYER EN LIGNE (gratuit)

### 1. Crée un compte GitHub
👉 [github.com](https://github.com)

### 2. Push ton code
- Télécharge **GitHub Desktop** : [desktop.github.com](https://desktop.github.com)
- File → Add Local Repository → Sélectionne `reviz-app`
- Publish repository

### 3. Déploie sur Render
👉 [render.com](https://render.com)

**Backend** :
- New → Web Service
- Build: `npm install`
- Start: `node server.js`

**Frontend** :
- New → Static Site
- Root: `client`
- Build: `npm install && npm run build`
- Publish: `client/build`

### 4. Configure les variables
Voir le fichier `RENDER_ENV_VARS.md` pour la liste complète

✅ **Ton app est en ligne !**

---

## 📚 Guides disponibles

| Fichier | Description | Temps |
|---------|-------------|-------|
| **QUICKSTART.md** | Démarrage détaillé | 5 min |
| **README.md** | Guide complet | 15 min |
| **TODO.md** | Plan d'action | 5 min |
| **MARKETING.md** | Promouvoir l'app | 10 min |
| **TROUBLESHOOTING.md** | Résoudre problèmes | 5 min |

---

## 🎯 Tes 3 premières actions

1. ✅ **Teste en local** (Option 1 ci-dessus)
2. ✅ **Fais tester à 5 amis**
3. ✅ **Lis le MARKETING.md** pour promouvoir

---

## 🆘 Problème ?

→ Ouvre **TROUBLESHOOTING.md**

---

**GO GO GO ! 🚀**
