# 🔧 Guide de Dépannage - Reviz

## 🚨 Problèmes courants et solutions

---

### 1. 🌐 "Cannot connect to backend" / "Network Error"

**Symptômes** :
- Le frontend s'affiche mais ne peut pas charger les fiches
- Message d'erreur dans la console : "Failed to fetch"

**Solutions** :

#### A. Vérifie les URLs

**En local** :
```bash
# Frontend doit pointer vers backend local
# Fichier : client/.env
REACT_APP_API_URL=http://localhost:3001
```

**En production (Render)** :
```bash
# Frontend doit pointer vers backend Render
# Fichier : Variables d'environnement Render
REACT_APP_API_URL=https://TON-BACKEND.onrender.com
```

#### B. Vérifie que le backend est bien démarré

**En local** :
```bash
# Ouvre http://localhost:3001/api/health dans ton navigateur
# Tu devrais voir : {"status": "OK", ...}
```

**Sur Render** :
```bash
# Ouvre https://TON-BACKEND.onrender.com/api/health
# Tu devrais voir : {"status": "OK", ...}
```

#### C. Vérifie CORS

Dans le backend, vérifie que `ALLOWED_ORIGINS` contient l'URL du frontend :
```
ALLOWED_ORIGINS=http://localhost:3000,https://TON-FRONTEND.onrender.com
```

---

### 2. 🤖 "OpenAI API error" / Erreur lors de la génération

**Symptômes** :
- Les fiches ne se génèrent pas
- Message : "Erreur lors de la génération des fiches"

**Solutions** :

#### A. Vérifie ta clé OpenAI

1. Va sur [platform.openai.com/api-keys](https://platform.openai.com/api-keys)
2. Vérifie que ta clé est active
3. Recopie-la dans `.env` ou Render

#### B. Vérifie ton crédit OpenAI

1. Va sur [platform.openai.com/usage](https://platform.openai.com/usage)
2. Vérifie que tu as du crédit restant
3. Si besoin, ajoute une carte bancaire

#### C. Teste directement l'API

```bash
curl https://api.openai.com/v1/chat/completions \
  -H "Authorization: Bearer TA_CLE" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "gpt-4",
    "messages": [{"role": "user", "content": "Hello"}]
  }'
```

Si ça marche pas → Problème avec ta clé OpenAI

---

### 3. 💳 Stripe : "Erreur lors du passage à Premium"

**Symptômes** :
- Le bouton "Passer à Premium" ne fonctionne pas
- Pas de redirection vers Stripe

**Solutions** :

#### A. Vérifie tes clés Stripe

1. Va sur [dashboard.stripe.com/test/apikeys](https://dashboard.stripe.com/test/apikeys)
2. Vérifie que tu es en mode **TEST** (pas LIVE)
3. Recopie les clés dans `.env` ou Render

#### B. Vérifie le Price ID

```bash
# Dans Stripe Dashboard
# Produits → Reviz Premium → Copie l'ID du tarif (price_...)
```

Vérifie que `STRIPE_PRICE_ID` = cet ID

#### C. Teste le endpoint Stripe

```bash
curl -X POST http://localhost:3001/api/stripe/create-checkout-session \
  -H "Content-Type: application/json" \
  -d '{"userId": "test123"}'
```

Tu devrais recevoir un `sessionId` et une `url`

---

### 4. 📦 "Module not found" / Erreurs d'import

**Symptômes** :
- L'app ne démarre pas
- Message : "Cannot find module 'xxx'"

**Solutions** :

#### A. Réinstalle les dépendances

```bash
# Backend
cd reviz-app
rm -rf node_modules package-lock.json
npm install

# Frontend
cd client
rm -rf node_modules package-lock.json
npm install
```

#### B. Vérifie ta version de Node.js

```bash
node --version
# Doit être >= 18.0.0
```

Si version trop ancienne, télécharge la dernière LTS sur [nodejs.org](https://nodejs.org)

---

### 5. 🐌 L'app est très lente sur Render

**Symptômes** :
- Premier chargement prend 30-60 secondes
- L'app "gèle" parfois

**Explication** :
C'est **NORMAL** avec le plan gratuit de Render. Les services se mettent en veille après 15 min d'inactivité.

**Solutions** :

#### A. Utilise un service de "ping" (gratuit)

Services comme [UptimeRobot](https://uptimerobot.com) envoient une requête toutes les 5 min pour garder ton app active.

#### B. Upgrade vers Render payant (7$/mois)

Le service reste toujours actif = pas de délai au premier chargement

#### C. Accepte le délai

Pour un MVP gratuit, c'est OK. Préviens tes utilisateurs : "Premier chargement peut prendre 1 minute"

---

### 6. 🔒 Problèmes de CORS / HTTPS

**Symptômes** :
- Erreur "Mixed Content" dans la console
- Requêtes bloquées par le navigateur

**Solutions** :

#### A. Vérifie que tu utilises HTTPS partout

```bash
# Les URLs doivent commencer par https:// (pas http://)
FRONTEND_URL=https://TON-FRONTEND.onrender.com
REACT_APP_API_URL=https://TON-BACKEND.onrender.com
```

#### B. En local, utilise HTTP partout

```bash
# Pour le développement local
FRONTEND_URL=http://localhost:3000
REACT_APP_API_URL=http://localhost:3001
```

---

### 7. 🎨 Le design est cassé / CSS ne charge pas

**Symptômes** :
- L'interface est toute blanche ou moche
- Pas de styles appliqués

**Solutions** :

#### A. Vérifie que index.css est importé

Dans `client/src/index.js` :
```javascript
import './styles/index.css';
```

#### B. Vide le cache du navigateur

1. Appuie sur `Ctrl + Shift + R` (Windows) ou `Cmd + Shift + R` (Mac)
2. Ou ouvre DevTools (F12) → Network → Coche "Disable cache"

#### C. Rebuild le frontend

```bash
cd client
rm -rf build
npm run build
```

---

### 8. 📱 Problèmes sur mobile

**Symptômes** :
- L'app fonctionne sur PC mais pas sur mobile
- Layout cassé sur petit écran

**Solutions** :

#### A. Vérifie la console mobile

Sur Chrome mobile :
1. Ouvre Chrome sur PC
2. Va sur `chrome://inspect`
3. Connecte ton téléphone
4. Inspecte l'app

#### B. Teste avec l'outil mobile de Chrome

Sur PC :
1. Appuie sur F12
2. Clique sur l'icône mobile (ou Ctrl + Shift + M)
3. Teste différentes tailles d'écran

---

### 9. 💾 Les données ne se sauvegardent pas

**Symptômes** :
- Les cours disparaissent après refresh
- La progression n'est pas sauvegardée

**Explication** :
En version MVP, les données sont dans `localStorage` (côté navigateur).

**Limitations** :
- Données effacées si on vide le cache
- Pas de sync entre appareils
- Perdu si on change de navigateur

**Solutions futures** :
- Ajouter une vraie base de données (MongoDB, PostgreSQL)
- Ajouter un système d'authentification
- Ça viendra dans une v2 si l'app marche bien !

---

### 10. 🔥 Render : "Build failed" / "Deploy failed"

**Symptômes** :
- Le déploiement échoue sur Render
- Messages d'erreur dans les logs

**Solutions** :

#### A. Vérifie les logs Render

1. Va sur ton service Render
2. Clique sur **Logs**
3. Lis le dernier message d'erreur
4. Google l'erreur pour trouver la solution

#### B. Erreurs communes

**"Module not found"** :
```bash
# Vérifie que package.json liste bien toutes les dépendances
```

**"Build command failed"** :
```bash
# Vérifie que le build command est correct :
# Backend : npm install
# Frontend : npm install && npm run build
```

**"Start command failed"** :
```bash
# Vérifie que le start command est correct :
# Backend : node server.js
```

---

## 🆘 Aide supplémentaire

### Où trouver les logs ?

**En local** :
- Backend : Regarde le terminal où tu as lancé `npm start`
- Frontend : Ouvre la console du navigateur (F12)

**Sur Render** :
- Va sur ton service → **Logs**
- Les erreurs y apparaissent en temps réel

### Commandes de diagnostic

```bash
# Vérifier que Node.js est installé
node --version

# Vérifier que npm est installé
npm --version

# Vérifier que le backend répond
curl http://localhost:3001/api/health

# Lister les processus Node en cours
# Mac/Linux
ps aux | grep node

# Windows
tasklist | findstr node
```

---

## 📞 Contacter le support

Si aucune solution ne fonctionne :

1. **Screenshot de l'erreur** (F12 → Console)
2. **Logs Render** (si en production)
3. **Ce que tu as essayé**
4. **Ton système** (Windows/Mac/Linux)

Et contacte-moi avec ces infos !

---

**La plupart des problèmes se résolvent en 5-10 minutes. Garde ton calme et lis les messages d'erreur ! 💪**
