import React from 'react';
import { Menu, Home, Crown } from 'lucide-react';

function Header({ userPlan, upgradeToPremium, goHome, toggleSidebar }) {
  return (
    <header style={{
      background: 'white',
      padding: '16px 24px',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      boxShadow: '0 2px 10px rgba(0,0,0,0.1)',
      position: 'sticky',
      top: 0,
      zIndex: 100
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
        <button
          onClick={toggleSidebar}
          style={{
            background: 'transparent',
            border: 'none',
            cursor: 'pointer',
            padding: '8px',
            borderRadius: '8px',
            display: 'flex',
            alignItems: 'center',
            transition: 'background 0.2s'
          }}
          onMouseEnter={(e) => e.target.style.background = '#f3f4f6'}
          onMouseLeave={(e) => e.target.style.background = 'transparent'}
        >
          <Menu size={24} color="#667eea" />
        </button>

        <button
          onClick={goHome}
          style={{
            background: 'transparent',
            border: 'none',
            cursor: 'pointer',
            padding: '8px',
            borderRadius: '8px',
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            transition: 'background 0.2s'
          }}
          onMouseEnter={(e) => e.target.style.background = '#f3f4f6'}
          onMouseLeave={(e) => e.target.style.background = 'transparent'}
        >
          <Home size={20} color="#667eea" />
        </button>

        <h1 style={{
          fontSize: '28px',
          fontWeight: 'bold',
          background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
          WebkitBackgroundClip: 'text',
          WebkitTextFillColor: 'transparent',
          margin: 0
        }}>
          Reviz
        </h1>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
        {userPlan === 'free' ? (
          <button
            onClick={upgradeToPremium}
            className="btn-primary"
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              padding: '10px 20px',
              fontSize: '14px'
            }}
          >
            <Crown size={18} />
            Passer à Premium
          </button>
        ) : (
          <div className="badge-premium" style={{ padding: '8px 16px' }}>
            <span style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
              <Crown size={16} />
              Premium
            </span>
          </div>
        )}
      </div>
    </header>
  );
}

export default Header;
