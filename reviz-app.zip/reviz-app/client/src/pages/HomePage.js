import React, { useState } from 'react';
import axios from 'axios';
import { Upload, FileText, Sparkles, BookOpen, CheckCircle } from 'lucide-react';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:3001';

function HomePage({ userId, userPlan, addCourse, upgradeToPremium }) {
  const [courseText, setCourseText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    if (courseText.trim().length < 50) {
      setError('Le cours doit contenir au moins 50 caractères.');
      return;
    }

    setIsLoading(true);

    try {
      const response = await axios.post(`${API_URL}/api/generate-flashcards`, {
        courseText: courseText.trim(),
        userId,
        userPlan
      });

      addCourse(response.data);
      setCourseText('');
    } catch (err) {
      console.error('Erreur:', err);
      setError(err.response?.data?.error || 'Une erreur est survenue lors de la génération des fiches.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      setCourseText(event.target.result);
    };
    reader.readAsText(file);
  };

  return (
    <div className="fade-in" style={{
      maxWidth: '900px',
      margin: '0 auto',
      padding: '40px 20px'
    }}>
      {/* Hero Section */}
      <div style={{
        textAlign: 'center',
        marginBottom: '48px'
      }}>
        <div style={{
          display: 'inline-block',
          padding: '8px 16px',
          background: 'rgba(255, 255, 255, 0.2)',
          borderRadius: '999px',
          marginBottom: '16px'
        }}>
          <span style={{
            color: 'white',
            fontSize: '14px',
            fontWeight: '600',
            display: 'flex',
            alignItems: 'center',
            gap: '6px'
          }}>
            <Sparkles size={16} />
            Révisions intelligentes propulsées par l'IA
          </span>
        </div>

        <h1 style={{
          fontSize: '48px',
          fontWeight: 'bold',
          color: 'white',
          marginBottom: '16px',
          lineHeight: '1.2'
        }}>
          Transformez vos cours<br/>en fiches et QCM
        </h1>

        <p style={{
          fontSize: '20px',
          color: 'rgba(255, 255, 255, 0.9)',
          maxWidth: '600px',
          margin: '0 auto',
          lineHeight: '1.6'
        }}>
          Collez votre cours, l'IA génère automatiquement des fiches de révision et des quiz personnalisés
        </p>
      </div>

      {/* Formulaire principal */}
      <div className="card" style={{ marginBottom: '32px' }}>
        <form onSubmit={handleSubmit}>
          <div style={{ marginBottom: '24px' }}>
            <label style={{
              display: 'block',
              fontSize: '16px',
              fontWeight: '600',
              color: '#1f2937',
              marginBottom: '12px'
            }}>
              Votre cours
            </label>
            
            <textarea
              value={courseText}
              onChange={(e) => setCourseText(e.target.value)}
              placeholder="Collez votre cours ici... (minimum 50 caractères)

Exemple :
La photosynthèse est le processus par lequel les plantes utilisent la lumière du soleil pour convertir le dioxyde de carbone et l'eau en glucose et en oxygène. Ce processus se déroule principalement dans les chloroplastes des cellules végétales..."
              className="textarea"
              disabled={isLoading}
            />

            <div style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginTop: '8px'
            }}>
              <span style={{
                fontSize: '14px',
                color: courseText.length >= 50 ? '#10b981' : '#9ca3af'
              }}>
                {courseText.length} caractères {courseText.length >= 50 ? '✓' : `(${50 - courseText.length} restants)`}
              </span>

              <label style={{
                cursor: 'pointer',
                color: '#667eea',
                fontSize: '14px',
                fontWeight: '600',
                display: 'flex',
                alignItems: 'center',
                gap: '6px'
              }}>
                <Upload size={16} />
                Importer un fichier texte
                <input
                  type="file"
                  accept=".txt"
                  onChange={handleFileUpload}
                  style={{ display: 'none' }}
                  disabled={isLoading}
                />
              </label>
            </div>
          </div>

          {error && (
            <div style={{
              padding: '12px 16px',
              background: '#fee2e2',
              color: '#991b1b',
              borderRadius: '8px',
              marginBottom: '16px',
              fontSize: '14px'
            }}>
              {error}
            </div>
          )}

          <button
            type="submit"
            className="btn-primary"
            disabled={isLoading || courseText.trim().length < 50}
            style={{
              width: '100%',
              padding: '16px',
              fontSize: '16px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '12px',
              opacity: (isLoading || courseText.trim().length < 50) ? 0.6 : 1,
              cursor: (isLoading || courseText.trim().length < 50) ? 'not-allowed' : 'pointer'
            }}
          >
            {isLoading ? (
              <>
                <div className="spinner" style={{ width: '20px', height: '20px', borderWidth: '2px' }} />
                Génération en cours...
              </>
            ) : (
              <>
                <Sparkles size={20} />
                Générer mes fiches de révision
              </>
            )}
          </button>
        </form>
      </div>

      {/* Features */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
        gap: '20px',
        marginTop: '48px'
      }}>
        <div className="card" style={{ textAlign: 'center' }}>
          <BookOpen size={40} color="#667eea" style={{ margin: '0 auto 16px' }} />
          <h3 style={{ fontSize: '18px', fontWeight: '600', color: '#1f2937', marginBottom: '8px' }}>
            Fiches automatiques
          </h3>
          <p style={{ fontSize: '14px', color: '#6b7280', lineHeight: '1.6' }}>
            L'IA identifie les concepts clés et crée des fiches de révision structurées
          </p>
        </div>

        <div className="card" style={{ textAlign: 'center' }}>
          <CheckCircle size={40} color="#667eea" style={{ margin: '0 auto 16px' }} />
          <h3 style={{ fontSize: '18px', fontWeight: '600', color: '#1f2937', marginBottom: '8px' }}>
            QCM personnalisés
          </h3>
          <p style={{ fontSize: '14px', color: '#6b7280', lineHeight: '1.6' }}>
            Des questions adaptées à chaque fiche pour tester vos connaissances
          </p>
        </div>

        <div className="card" style={{ textAlign: 'center' }}>
          <Sparkles size={40} color="#667eea" style={{ margin: '0 auto 16px' }} />
          <h3 style={{ fontSize: '18px', fontWeight: '600', color: '#1f2937', marginBottom: '8px' }}>
            Suivi de progression
          </h3>
          <p style={{ fontSize: '14px', color: '#6b7280', lineHeight: '1.6' }}>
            Visualisez votre avancement et maîtrisez chaque cours progressivement
          </p>
        </div>
      </div>

      {/* Limite version gratuite */}
      {userPlan === 'free' && (
        <div className="card" style={{
          marginTop: '40px',
          background: 'linear-gradient(135deg, rgba(102, 126, 234, 0.1) 0%, rgba(118, 75, 162, 0.1) 100%)',
          border: '2px solid #667eea'
        }}>
          <div style={{ display: 'flex', alignItems: 'start', gap: '16px' }}>
            <div style={{
              flex: 1
            }}>
              <h3 style={{
                fontSize: '18px',
                fontWeight: '600',
                color: '#1f2937',
                marginBottom: '8px'
              }}>
                Version gratuite
              </h3>
              <ul style={{
                fontSize: '14px',
                color: '#6b7280',
                lineHeight: '1.8',
                paddingLeft: '20px'
              }}>
                <li>3 fiches maximum par cours</li>
                <li>5 questions par QCM</li>
                <li>Cours illimités</li>
              </ul>
            </div>
            <button
              onClick={upgradeToPremium}
              className="btn-primary"
              style={{
                whiteSpace: 'nowrap',
                padding: '12px 24px'
              }}
            >
              Passer à Premium
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default HomePage;
