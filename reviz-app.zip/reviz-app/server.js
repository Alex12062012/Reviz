require('dotenv').config();
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const OpenAI = require('openai');
const { v4: uuidv4 } = require('uuid');

const app = express();
const PORT = process.env.PORT || 3001;

// OpenAI Configuration
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// Middleware
app.use(cors({
  origin: process.env.ALLOWED_ORIGINS?.split(',') || ['http://localhost:3000'],
  credentials: true
}));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Base de données en mémoire (pour MVP - à remplacer par vraie DB plus tard)
const database = {
  users: new Map(),
  courses: new Map(),
  flashcards: new Map(),
  progress: new Map()
};

// ========== ROUTES API ==========

// Route de test
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'OK', 
    message: 'Reviz API is running!',
    timestamp: new Date().toISOString()
  });
});

// Route pour obtenir la clé publique Stripe
app.get('/api/stripe/public-key', (req, res) => {
  res.json({ 
    publicKey: process.env.STRIPE_PUBLIC_KEY 
  });
});

// Route pour créer une session de paiement Stripe
app.post('/api/stripe/create-checkout-session', async (req, res) => {
  const { userId } = req.body;

  try {
    const session = await stripe.checkout.sessions.create({
      mode: 'subscription',
      payment_method_types: ['card'],
      line_items: [
        {
          price: process.env.STRIPE_PRICE_ID,
          quantity: 1,
        },
      ],
      success_url: `${process.env.FRONTEND_URL}/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.FRONTEND_URL}/pricing`,
      client_reference_id: userId || uuidv4(),
      metadata: {
        userId: userId || uuidv4()
      }
    });

    res.json({ sessionId: session.id, url: session.url });
  } catch (error) {
    console.error('Stripe checkout error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Webhook Stripe pour gérer les événements de paiement
app.post('/api/stripe/webhook', express.raw({ type: 'application/json' }), async (req, res) => {
  const sig = req.headers['stripe-signature'];
  let event;

  try {
    event = stripe.webhooks.constructEvent(
      req.body,
      sig,
      process.env.STRIPE_WEBHOOK_SECRET
    );
  } catch (err) {
    console.error('Webhook signature verification failed:', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  // Gérer les événements
  switch (event.type) {
    case 'checkout.session.completed':
      const session = event.data.object;
      const userId = session.metadata.userId;
      
      // Mettre à jour l'utilisateur en Premium
      if (database.users.has(userId)) {
        const user = database.users.get(userId);
        user.plan = 'premium';
        user.stripeSubscriptionId = session.subscription;
        user.premiumSince = new Date();
        database.users.set(userId, user);
      }
      
      console.log('✅ User upgraded to Premium:', userId);
      break;

    case 'customer.subscription.deleted':
      // Annulation d'abonnement
      const subscription = event.data.object;
      console.log('❌ Subscription cancelled:', subscription.id);
      break;

    default:
      console.log(`Unhandled event type ${event.type}`);
  }

  res.json({ received: true });
});

// Route pour générer des fiches à partir d'un cours
app.post('/api/generate-flashcards', async (req, res) => {
  const { courseText, userId, userPlan = 'free' } = req.body;

  if (!courseText || courseText.trim().length < 50) {
    return res.status(400).json({ 
      error: 'Le texte du cours doit contenir au moins 50 caractères.' 
    });
  }

  try {
    const maxCards = userPlan === 'premium' ? 999 : 3;

    // Appel à OpenAI pour générer les fiches
    const completion = await openai.chat.completions.create({
      model: "gpt-4",
      messages: [
        {
          role: "system",
          content: `Tu es un assistant éducatif expert. Ta tâche est d'analyser un cours et d'en extraire les concepts clés pour créer des fiches de révision.
          
Pour chaque concept important, crée une fiche avec :
- title: Un titre clair et concis du concept
- keywords: 3-5 mots-clés essentiels
- summary: Un résumé de 2-3 phrases
- keyPoints: 3-5 points essentiels (array de strings)

Réponds UNIQUEMENT avec un JSON valide dans ce format :
{
  "flashcards": [
    {
      "title": "Titre du concept",
      "keywords": ["mot1", "mot2", "mot3"],
      "summary": "Résumé concis du concept...",
      "keyPoints": ["Point 1", "Point 2", "Point 3"]
    }
  ],
  "totalConceptsDetected": 8
}

Limite-toi à extraire les ${maxCards} concepts les plus importants.`
        },
        {
          role: "user",
          content: `Voici le cours à analyser :\n\n${courseText}`
        }
      ],
      temperature: 0.7,
      max_tokens: 2000
    });

    const responseText = completion.choices[0].message.content;
    const data = JSON.parse(responseText);

    // Générer des IDs uniques pour chaque fiche
    const flashcards = data.flashcards.map(card => ({
      id: uuidv4(),
      ...card
    }));

    // Sauvegarder les fiches
    const courseId = uuidv4();
    database.flashcards.set(courseId, {
      courseId,
      userId,
      flashcards,
      createdAt: new Date(),
      totalConceptsDetected: data.totalConceptsDetected
    });

    res.json({
      courseId,
      flashcards: flashcards.slice(0, maxCards),
      totalConceptsDetected: data.totalConceptsDetected,
      isLimited: userPlan === 'free' && data.totalConceptsDetected > 3
    });

  } catch (error) {
    console.error('OpenAI generation error:', error);
    res.status(500).json({ 
      error: 'Erreur lors de la génération des fiches.',
      details: error.message 
    });
  }
});

// Route pour générer un QCM à partir d'une fiche
app.post('/api/generate-quiz', async (req, res) => {
  const { flashcardId, flashcardContent, userPlan = 'free' } = req.body;

  if (!flashcardContent) {
    return res.status(400).json({ 
      error: 'Le contenu de la fiche est requis.' 
    });
  }

  try {
    const maxQuestions = userPlan === 'premium' ? 20 : 5;

    const completion = await openai.chat.completions.create({
      model: "gpt-4",
      messages: [
        {
          role: "system",
          content: `Tu es un expert en création de QCM éducatifs. 

Crée ${maxQuestions} questions à choix multiples basées sur le contenu fourni.

Pour chaque question :
- question: La question posée
- options: Array de 4 réponses possibles
- correctAnswer: L'index (0-3) de la bonne réponse
- explanation: Explication de pourquoi c'est la bonne réponse

Réponds UNIQUEMENT avec un JSON valide :
{
  "questions": [
    {
      "question": "Quelle est...",
      "options": ["Réponse A", "Réponse B", "Réponse C", "Réponse D"],
      "correctAnswer": 2,
      "explanation": "Explication..."
    }
  ]
}`
        },
        {
          role: "user",
          content: `Crée un QCM basé sur cette fiche :\n\nTitre: ${flashcardContent.title}\n\nRésumé: ${flashcardContent.summary}\n\nPoints clés: ${flashcardContent.keyPoints.join(', ')}`
        }
      ],
      temperature: 0.8,
      max_tokens: 1500
    });

    const responseText = completion.choices[0].message.content;
    const data = JSON.parse(responseText);

    // Ajouter des IDs
    const questions = data.questions.map(q => ({
      id: uuidv4(),
      ...q
    }));

    res.json({
      quizId: uuidv4(),
      flashcardId,
      questions: questions.slice(0, maxQuestions),
      isLimited: userPlan === 'free'
    });

  } catch (error) {
    console.error('Quiz generation error:', error);
    res.status(500).json({ 
      error: 'Erreur lors de la génération du quiz.',
      details: error.message 
    });
  }
});

// Route pour sauvegarder la progression d'un quiz
app.post('/api/save-progress', (req, res) => {
  const { userId, courseId, flashcardId, score, totalQuestions } = req.body;

  const progressKey = `${userId}-${courseId}-${flashcardId}`;
  
  database.progress.set(progressKey, {
    userId,
    courseId,
    flashcardId,
    score,
    totalQuestions,
    percentage: Math.round((score / totalQuestions) * 100),
    completedAt: new Date()
  });

  res.json({ 
    success: true,
    message: 'Progression sauvegardée' 
  });
});

// Route pour récupérer la progression globale d'un cours
app.get('/api/progress/:userId/:courseId', (req, res) => {
  const { userId, courseId } = req.params;

  const courseProgress = [];
  
  for (const [key, progress] of database.progress.entries()) {
    if (key.startsWith(`${userId}-${courseId}`)) {
      courseProgress.push(progress);
    }
  }

  const totalPercentage = courseProgress.length > 0
    ? Math.round(courseProgress.reduce((sum, p) => sum + p.percentage, 0) / courseProgress.length)
    : 0;

  res.json({
    courseProgress,
    totalPercentage,
    completedFlashcards: courseProgress.length
  });
});

// Démarrage du serveur
app.listen(PORT, () => {
  console.log(`
  ╔════════════════════════════════════════╗
  ║         🎓 REVIZ API SERVER           ║
  ║                                        ║
  ║  Status: ✅ Running                    ║
  ║  Port: ${PORT}                       ║
  ║  Environment: ${process.env.NODE_ENV || 'development'}         ║
  ║                                        ║
  ║  Endpoints:                            ║
  ║  - GET  /api/health                    ║
  ║  - POST /api/generate-flashcards       ║
  ║  - POST /api/generate-quiz             ║
  ║  - POST /api/stripe/create-checkout    ║
  ║                                        ║
  ╚════════════════════════════════════════╝
  `);
});

module.exports = app;
